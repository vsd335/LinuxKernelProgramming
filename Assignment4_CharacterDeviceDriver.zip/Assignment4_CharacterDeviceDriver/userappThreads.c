// Name: Vinayak Deshpande
// UFID: 4102 9538

#include <linux/ioctl.h>
#include <unistd.h>
#include <sys/ioctl.h>
#include <time.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <pthread.h>


#define DEVICE "/dev/mycdrv"

#define CDRV_IOC_MAGIC 'Z'
#define ASP_CHGACCDIR _IOW(CDRV_IOC_MAGIC, 1, int)

int f0, f1, f2;
#define nTHread 5
pthread_t threads[nTHread];
pthread_t threads2[nTHread];

void *wr_thread(void *arg)
{
	int t_size = 20;
	char buf[t_size];
	int id = (int)arg;
	int i=0;
	while(i<65536/nTHread/20)
	{
		sprintf(buf, "vinyak_%d_%d\n", id,i);
		lseek(f0, rand()%65535, SEEK_SET);		
		write(f0, buf, t_size);
		i++;
	}

	return 0;
}

void *rd_thread(void *arg)
{
	int t_size = 20;
	char buf[t_size];
	int id = (int)arg;
	int i =0;

	while(i<65536/nTHread/20)
	{
		lseek(f0, rand()%65535, SEEK_SET);		
		read(f0, buf, t_size);
		printf("Data read from mycdrv0 : %s", buf);
		i++;
	}

}

int main(int argc, char *argv[]) {

	int m;
	int n;

	f0 = open("/dev/mycdrv0", O_RDWR);
	
	lseek(f0, 0, SEEK_SET);
	lseek(f0, 100, SEEK_END);	
	for (m=0; m<nTHread; m++)
	{
		pthread_create(&(threads[m]), NULL, wr_thread, (void*)m);
		pthread_create(&(threads2[m]), NULL, rd_thread, (void*)m);

	}

	for (n=0; n<nTHread; n++)
	{
		pthread_join(threads[n], NULL);
	}
	

	for (n=0; n<nTHread; n++)
	{
		pthread_join(threads2[n], NULL);
	}

	close(f0);

	return 0;
}
