/* ============================================================================================

	Name : Vinayak Deshpande
	UFID : 4102 9538
	Description : * Implements a simple charcter device driver
				  * Based on input during insmod, specified number of devices will be created
				  * Basic file operations like read, write, llseek and ioctl are implemented
	
============================================================================================ */

#include <linux/version.h>
#include <linux/module.h>
#include <linux/moduleparam.h>
#include <linux/init.h>
#include <linux/kernel.h>
#include <linux/slab.h>
#include <linux/fs.h>
#include <linux/errno.h>
#include <linux/err.h>
#include <linux/cdev.h>
#include <linux/device.h>
#include <linux/list.h>
#include <asm/uaccess.h>

#define MY_CHR_DEV_NAME "mycdrv"	 // characher device driver name

#define ramdisk_size (size_t) (16 * PAGE_SIZE) // ramdisk size 

//data access directions
#define DAD_REGULAR 0
#define DAD_REVERSE 1

//NUM_DEVICES defaults to 3 unless specified during insmod
static int NUM_DEVICES = 3;

#define CDRV_IOC_MAGIC 'Z'
#define ASP_CHGACCDIR _IOW(CDRV_IOC_MAGIC, 1, int)


struct ASP_mycdrv {
	struct list_head list;
	struct cdev dev;
	char *ramdisk;
	struct semaphore sem;
	int devNo;
	long acc_dir_md;
};

// declaration of major number, class type and ASP_mycdrv type
module_param(NUM_DEVICES, int, S_IRUGO);
static unsigned int mycdrv_major = 0;
static struct class *mycdrv_class = NULL;
static struct ASP_mycdrv *ASP_mycdrv_devices = NULL;
static int mycdrv_ramdisk_size = ramdisk_size;

/* implementation to open the function */
int  mycdrv_open(struct inode *inode, struct file *filp) {
	unsigned int majNo = imajor(inode);
	unsigned int minNo = iminor(inode);
	
	struct ASP_mycdrv *chr_dev = NULL;
	
	if (majNo != mycdrv_major || minNo < 0 || minNo >= NUM_DEVICES)
	{
		printk(KERN_WARNING "No device with minor=%d and major=%d exist\n", minNo, majNo);
		return -ENODEV; 	// no such device
	}
	
	chr_dev = &ASP_mycdrv_devices[minNo];
	filp->private_data = chr_dev; 
	
	return 0;
}

/* implementation to release function */
int mycdrv_release(struct inode *inode, struct file *filp) {
        return 0;
}

/* copying data to application code */
ssize_t mycdrv_read(struct file *filp, char __user *buf, size_t count,loff_t *f_pos) {
	
	struct ASP_mycdrv *chr_dev = (struct ASP_mycdrv *)filp->private_data;
	unsigned char *tempBuff = NULL;
	int k;
	ssize_t retval = 0;

	if (down_interruptible(&(chr_dev->sem))!=0)
 	{
		pr_err("%s: not able to lock semaphore\n", MY_CHR_DEV_NAME);
	}

	if(count < 0 || *f_pos < 0)
	{
		retval = -EINVAL;
		goto out;
	}

	else if (*f_pos > mycdrv_ramdisk_size)
	{
		retval = -EINVAL;
		goto out;
	}
	else if ((chr_dev->acc_dir_md == DAD_REGULAR) && (*f_pos + count > mycdrv_ramdisk_size -1)) 
 	{
		count = mycdrv_ramdisk_size - *f_pos;
	}

	else if((chr_dev->acc_dir_md == DAD_REVERSE) && (*f_pos + 1 - count < 0))
	{
		count = *f_pos+1;
	}

	tempBuff = (unsigned char*) kzalloc(count, GFP_KERNEL);	
	
	if (tempBuff == NULL)
 	{
		printk(" out of memory operation has failed");
		retval = -ENOMEM;
		goto out;
	}
	if(chr_dev->acc_dir_md == DAD_REGULAR)
	{
		for (k = 0; k < count; k++)
 		{
			tempBuff[k] = chr_dev->ramdisk[*f_pos + k];
		}
		*f_pos += count;
	}
	else
	{
		for (k = 0; k < count; k++)
 		{
			tempBuff[k] = chr_dev->ramdisk[*f_pos - k];
		}
		*f_pos -= count;
	}

	copy_to_user(buf, tempBuff, count);
	retval = count;

out:
	printk("exiting the read!!!\n");
	if (tempBuff != NULL)
	{
		kfree(tempBuff);
	}
	up(&(chr_dev->sem));
	return retval;
}

/* copying data from application code */
ssize_t mycdrv_write(struct file *filp, const char __user *buf, size_t count, loff_t *f_pos) {
	
	struct ASP_mycdrv *chr_dev = (struct ASP_mycdrv *)filp->private_data;
	ssize_t retval = 0;
	unsigned char *tempBuff = NULL;

	loff_t i;

	if (down_interruptible(&(chr_dev->sem))!=0) {
		pr_err("%s: unable to lock the semaphore\n", MY_CHR_DEV_NAME);
	}

	if(count < 0 || *f_pos < 0){
		retval = -EINVAL;
		goto out;
	}
	
	else if (*f_pos > mycdrv_ramdisk_size)
 	{	
		retval = -EINVAL;
		goto out;
	}

	else if ((chr_dev->acc_dir_md == DAD_REGULAR) && (*f_pos + count > mycdrv_ramdisk_size -1)) 
 	{
		count = mycdrv_ramdisk_size - *f_pos;
	}

	else if((chr_dev->acc_dir_md == DAD_REVERSE) && (*f_pos + 1 - count < 0))
	{
		count = *f_pos+1;
	}

	tempBuff = (unsigned char*) kzalloc(count, GFP_KERNEL);	
	
	if (tempBuff == NULL)
 	{	
		retval = -ENOMEM;
		goto out;
	}

	copy_from_user(tempBuff, buf, count);
	
	if(chr_dev->acc_dir_md == DAD_REGULAR)
	{
		for (i = 0; i < count; i++)
 		{
			chr_dev->ramdisk[*f_pos + i] = tempBuff[i];
		}
		*f_pos += count;
	}
	else
	{
		for (i = 0; i < count; i++)
	 	{
			chr_dev->ramdisk[*f_pos - i] = tempBuff[i];
		}
		*f_pos =*f_pos-count;
	}
	retval = count;
	
out:
	if (tempBuff != NULL)
		kfree(tempBuff);

	up(&(chr_dev->sem));
	return retval;
}


/* Seeking a Device */
loff_t mycdrv_llseek(struct file *filp, loff_t off, int whence) {

	struct ASP_mycdrv *chr_dev = (struct ASP_mycdrv *)filp->private_data;
	loff_t new_pos;


	if(down_interruptible(&(chr_dev->sem)) != 0)
	{
		pr_err("%s: not able to lock the semaphore\n",MY_CHR_DEV_NAME);
	}

	switch(whence)
	{
	case 0: 	// beginning
		new_pos = off;		
		break;
		
	case 1:		// current

		new_pos = filp->f_pos + off;
		break;
		
	case 2:		// end

		new_pos = mycdrv_ramdisk_size -1 + off;
		break;
	default:
		new_pos = -EINVAL;
		goto fail;
	}

	if(new_pos < 0 || new_pos > mycdrv_ramdisk_size -1)
	{
		new_pos = -EINVAL;
		goto fail;
	}

	filp->f_pos = new_pos;
fail:
	up(&(chr_dev->sem));
	return new_pos;
	
}


/* Input Output ConTroL(ioctl) implementation */
long mycdrv_ioctl(struct file *filp, unsigned int in_cmd, unsigned long acc_dir) {

	struct ASP_mycdrv *chr_dev = (struct ASP_mycdrv *)filp->private_data;

	int req_dir;
	long retval;
	
	if(in_cmd != ASP_CHGACCDIR)
	{
		return -1;
	}
	
	copy_from_user(&req_dir,(int*)acc_dir,sizeof(int)*1);
	
	if(req_dir != DAD_REGULAR && req_dir != DAD_REVERSE)
	{
		return -1;
	}
	
	if(down_interruptible(&(chr_dev->sem))!=0)
	{
		pr_err("%s: not able to lock the semaphore\n",MY_CHR_DEV_NAME);
	}
	
	retval = chr_dev->acc_dir_md;
	chr_dev->acc_dir_md = req_dir;
	up(&(chr_dev->sem));
	return retval;
}

struct file_operations mycdrv_fops = {
	.owner          =    	THIS_MODULE,
	.read           =       mycdrv_read,
	.write          =    	mycdrv_write,
	.open           =    	mycdrv_open,
	.release        =       mycdrv_release,
	.llseek         = 		mycdrv_llseek,
	.unlocked_ioctl =       mycdrv_ioctl,
};


/* Create a new device with provided minor number */
static int mycdrv_create_dev(struct ASP_mycdrv *chr_dev, int dev_minor, struct class *dev_class) {
	
	int err = 0;
	dev_t devNo = MKDEV(mycdrv_major, dev_minor);
	
	struct device *c_device = NULL;
	
	/* Allocate memory for the first time device is opened */
	chr_dev->dev.owner = THIS_MODULE;
	chr_dev->ramdisk = (unsigned char*)kzalloc(mycdrv_ramdisk_size, GFP_KERNEL);
	sema_init(&chr_dev->sem, 1);
	chr_dev->acc_dir_md = DAD_REGULAR; 
	
	cdev_init(&chr_dev->dev, &mycdrv_fops);				// initialize a cdev structure
	
	err = cdev_add(&chr_dev->dev, devNo, 1);			// add a char device to the system
	if(err) {
		
		printk(KERN_WARNING "Error %d while adding %s%d", err, MY_CHR_DEV_NAME, dev_minor);
		return err;
	}
	
	/* creates a device and registers it with sysfs */
	c_device = device_create(dev_class, NULL, devNo, NULL, MY_CHR_DEV_NAME "%d", dev_minor); 
	
	if(IS_ERR(c_device)) {
		
		err = PTR_ERR(c_device);
		printk(KERN_WARNING "Error %d while creating %s%d",err, MY_CHR_DEV_NAME, dev_minor);
		cdev_del(&chr_dev->dev);						// remove a cdev from the system
		return err;
		
	}
	
	return 0;
}

/* remove the device completely from the system */
static void remove_device(struct ASP_mycdrv *chr_dev, int dev_minor, struct class *dev_class)
{

	device_destroy(dev_class, MKDEV(mycdrv_major, dev_minor));
	cdev_del(&chr_dev->dev);
	kfree(chr_dev->ramdisk);
	return;
}

/* delete the devices from the system if any */
static void destroy_module(int dev_to_destroy) {
	
	int k;
	
	if(ASP_mycdrv_devices) {
		
		for(k = 0; k < dev_to_destroy; ++k) {
			
			remove_device(&ASP_mycdrv_devices[k], k, mycdrv_class);
		}
			
		kfree(ASP_mycdrv_devices);
	}
	
	if(mycdrv_class) 
			class_destroy(mycdrv_class);
	
	unregister_chrdev_region(MKDEV(mycdrv_major, 0), NUM_DEVICES);
	return;
	
}

/*  Allocates memory and initializes all the module specific parameters and function pointers */
static int __init my_init(void) {
	
	int err = 0;
	int j = 0;
	int dev_to_destroy = 0;
	dev_t dev = 0;
	
	if (NUM_DEVICES <= 0) {
		
		printk(KERN_WARNING "Invalid number of devices passed = %d\n",NUM_DEVICES);
		err = -EINVAL;	// Invalid argument
		return err;
	}
	
	/* Obtain a range minor numbers for the speified number of devices (starting with 0) */
	err = alloc_chrdev_region(&dev, 0, NUM_DEVICES, MY_CHR_DEV_NAME);
	if (err < 0) {
		
		printk(KERN_WARNING "alloc_chrdev_region() failed\n");
		return err;
	}
	
	mycdrv_major = MAJOR(dev);	// dynamically allocated major number of the devices

	/* Create device class */
	mycdrv_class = class_create(THIS_MODULE, MY_CHR_DEV_NAME);
	if(IS_ERR(mycdrv_class)) {	// to check if class_create() has succeeded
		
		err = PTR_ERR(mycdrv_class); 
		goto failure;			// to destroy device
		
	}
	
	/* Allocate the array of devices created */
	ASP_mycdrv_devices = (struct ASP_mycdrv *)kzalloc(NUM_DEVICES *sizeof(struct ASP_mycdrv), GFP_KERNEL);
	if(ASP_mycdrv_devices == NULL) {
		
		err = -ENOMEM; 			// not enough space
		goto failure;			// to destroy device
		
	}
	
	/* Construct the devices */
	for (j = 0; j < NUM_DEVICES; j++) {
		
		err = mycdrv_create_dev(&ASP_mycdrv_devices[j], j, mycdrv_class);
		if(err) {
			
			dev_to_destroy = j;
			goto failure;		// to destroy device
			
		}
	}
	
	return 0; 				// 0 is returned on successful creation of device
	
failure:
	destroy_module(dev_to_destroy);
	return err;
	
}

/*  Releases all resources held by the driver module(s) and unregisters the module */
static void __exit my_exit(void) {
	
	destroy_module(NUM_DEVICES);
	return;
}

module_init(my_init);
module_exit(my_exit);

MODULE_AUTHOR("Vinayak Deshpande");
MODULE_LICENSE("GPL v2");
