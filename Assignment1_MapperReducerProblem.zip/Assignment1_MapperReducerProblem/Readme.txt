Name : Vinayak Deshpande 
UFID : 4102 9538
Date : 01/22/2016

I. Files Included
-----------------
Mapper.c		- Maps the words from the input file and writes to the standard output
Reducer.c		- Reduces the mapped words in the format (word,total) and prints on standard output
Combiner.c		- Uses various system calls like fork,exec,pipe and dup2 to implement Mapper-Reducer
Makefile		- Consists of all necessary commands to run the Mapper and Reducer,Combiner programs in once step
Inputfile.txt		- This file has a list of words and it is input to the Combiner program


II. How to run the Combiner
---------------------------

Command Line Arguments and outputs

Step1 : make
Step2 : ./Combiner <input text file here>

Outputs:
The Reduced (word,total) key-value pairs are displayed on the standard output.


III. Design decisions
---------------------

Implementation of MAPPER PROGRAM

The program reads the input sequence of words from a text file
Displays the key-value pairs in the (word,1) format on the standard output
Stores the key-value pairs into an output text file

Implementation of REDUCER PROGRAM

The program reads the (word,1) key-value pairs from Standard Input
Generates	(word,total) key-­value pairs on	the	standard output
Also stores the (word,total) key-­value pairs into an output text file

Implementation of COMBINER PROGRAM

The program implements a PIPE to share data between two child processes
Two child processes are created using FORK which execute the MAPPER and REDUCER programs
The program also makes use of DUP2 to successfully establish Inter-Process communication
EXEC system call replaces the current child program with new Mapper & Reducer programs  
Finally the (word,total) key-value pairs are displayed on the standard output
