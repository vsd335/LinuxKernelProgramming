//Vinayak Deshpande : UFID - 4102 9538

//Implementation of REDUCER PROGRAM

//The program reads the (word,1) key-value pairs from Standard Input
//Generates	(word,total) key-­value pairs on	the	standard output
//Also stores the (word,total) key-­value pairs into an output text file


#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>


#define MAX 1000

int main (int argc, char *argv[]) {


    FILE *fp;           // pointer to the file
    char buf[30];       // character variable to hold the strings from the file
    char *x[MAX],*y[MAX];       // pointer variable to store all the words from the file
    int i = 0,j = 0,m = 0,k = 0;
    int n = 0;          // holds the number of words in the file. 
    char *temp1,*temp2;


    // Reducer program starts here. Finding out the number of times a word has repeated

    // Reading the key-value pairs from the MAPPER program
		while(read(STDIN_FILENO,buf,sizeof(buf))) {

	            x[n] = strdup(buf);
	            temp1 = x[n-1]; 
	            temp2 = x[n];   
	            n++;			

	            if(n>2){
	            	if(temp1[0] != temp2[0]) {
	            			for(i=0;i<n;i++) {
	            				temp1 = x[i];
	            				for(j=i+1;j<n+1;j++) {
	            					temp2 = x[j];
	            					if(strcmp(temp1,temp2) == 0) {
	        							m++;
	        							for(k=j;k<n;k++)			// removing the repeated word from the list
	        								x[k] = x[k+1];
	        							j--;
	        							n--;
	        						}
	        						else if (temp1[0] != temp2[0]) {
	        							m++;
	        		    				printf("(%s,%d)\n",x[i],m);
	        		    				m = 0;
	        		    				break;
	        						}

	            				}

	            				if(j == n-1 && i == n-2){
	            					x[0] = x[n-1]; 
	            					n = 1;
	            					break;
	            				} 

	            			}

	            	}


	            }
	 	}
	
	 	x[n] = NULL;

	 	for(i=0;i<n;i++) {
	        temp1 = x[i];
	            for(j=i+1;j<n+1;j++) {
	            	temp2 = x[j];
	            	if(temp2 != NULL) {
	            		if(strcmp(temp1,temp2) == 0 && j != n) {
		            		m++;
		        			for(k=j;k<n;k++)			// removing the repeated word from the list
		        				x[k] = x[k+1];
		        			j--;
		        			n--;
	        			}
	        			else if (j == n) {
		        			m++;
		        		    printf("(%s,%d)\n",x[i],m);
		        		    m = 0;
		        		    break;
	        			}
	        		}
	        		else {
	            		m++;
	        		    printf("(%s,%d)\n",x[i],m);
	        		    m = 0;
	        		    break;
	        		}
	        }
	    } 

 	return 0;
}

