//Vinayak Deshpande : UFID - 4102 9538

//Implementation of COMBINER PROGRAM

//The program implements a PIPE to share data between two child processes
//Two child processes are created using FORK which execute the MAPPER and REDUCER programs
//The program also makes use of DUP2 to successfully establish Inter-Process communication
//EXEC system call replaces the current child program with new Mapper & Reducer programs  
//Finally the (word,total) key-value pairs are displayed on the standard output

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>


#define READ_END 0
#define WRITE_END 1

int main(int argc,char *argv[]) {

	FILE *fp;                				// pointer to the file
	pid_t mapperChild,reducerChild;			// PIDs for Children that execute Mapper and Reducer programs
	int ret1;
	int pipeEndsMapRed[2];					// to hold the File Descriptors of Read and Write ends of Mapper

	// Checking for input arguments
    if(argc != 2) {
        if(argc < 2)
        printf("Insufficient arguments passed\n");
        else
        printf("Too many arguments passed\n");
        printf("usage: pass an input text file containing words\n");
        return 1;
    }

	// Opening the input file containing Words
	fp = fopen(argv[1], "r");

        if(fp == NULL) {
            printf("Cannot open the file.\n");
            printf("Input a valid text file..\n");
            exit(1);
        }

    fclose(fp);

	// Creation of pipe for inter-process communication
	ret1 = pipe(pipeEndsMapRed);			// creation of read and write ends of pipe for Mapper-Reducer

	if(ret1 == -1) {

		perror("pipe failed");			    // executed if pipe creation fails 	
		exit(1);

	}


	// Creation of Mapper Child and Parent processes using fork
	reducerChild = fork();

	if (reducerChild == 0) {

		// Child process 1 to run REDUCER program 

		printf("\nI am in CHILD process 1: REDUCER program with PID: %d\n",(int) getpid());

		// Mapping of READ end of Pipe
				dup2(pipeEndsMapRed[READ_END],STDIN_FILENO);	 // mapping Standard input to Read end of Pipe.
				close(pipeEndsMapRed[WRITE_END]);				 // closing Write end 

				execlp("./Reducer", "./Reducer", NULL);
				printf("Exec error\n"); 	    				 // executed by child 2 process only if execlp fails
 

	}

	else if (reducerChild > 0) {

		mapperChild = fork();

			if (mapperChild == 0) {

				// Child process 2 to run MAPPER program
				sleep(1);
				printf("\nI am in CHILD process 2: MAPPER program with PID: %d\n",(int) getpid());
				printf("\nFollowing is the List of Reduced (word,total) Key-Value pairs:\n\n");

				// Mapping of WRITE end of pipe
				dup2(pipeEndsMapRed[WRITE_END],STDOUT_FILENO);			// mapping Standard output to Write end of Pipe.
				close(pipeEndsMapRed[READ_END]);						// closing Read end	

				execlp("./Mapper", "./Mapper", argv[1], NULL);
				printf("Exec error\n"); 	    						// executed by child 1 process only if execlp fails

			}

			else if (mapperChild > 0) {

				// Parent process
				close(pipeEndsMapRed[WRITE_END]);
				close(pipeEndsMapRed[READ_END]);	
				printf("\nI am in PARENT process with PID: %d\n",(int) getpid());
				waitpid(-1,NULL,0);

			}

			else
				
				printf("Second FORK failed\n");
	}

	else

		printf("First FORK failed\n");

return 0;

} 





