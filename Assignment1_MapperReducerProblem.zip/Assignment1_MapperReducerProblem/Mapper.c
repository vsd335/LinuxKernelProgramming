//Vinayak Deshpande : UFID - 4102 9538

//Implementation of MAPPER PROGRAM

//The program reads the input sequence of words from a text file
//Displays the key-value pairs in the (word,1) format on the standard output
//Stores the key-value pairs into an output text file


#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>


int main (int argc, char *argv[]) {


    FILE *fp;                // pointer to the file
    char str[30] = {};       // character variable to hold the words from the file
 

    // Opening the input file containing Words
        fp = fopen(argv[1], "r");
 

    // Reading the Words from the input file
        while(!feof(fp)) {
            while(fgets(str, sizeof str, fp)) {
                str[strlen(str)-1] = '\0';      // removes the newline character present at the end of each word
                write(STDOUT_FILENO,str,sizeof(str));
            }
        }   

        fclose(fp);

    return 0;
}
