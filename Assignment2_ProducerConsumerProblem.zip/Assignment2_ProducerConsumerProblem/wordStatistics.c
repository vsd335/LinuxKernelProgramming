/* 
	NAME : Vinayak Deshpande
	UFID : 4102 9538

*/

#include "stdio.h"
#include "stdlib.h"
#include "string.h"
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <pthread.h>


// Global variables
#define MAX 20000
FILE *fp,*fr,*fs;
int N = 20;
int numM = 0,numR = 0,numS = 0,numW = 0,numL = 0;
int inM = 0,inR = 0,inS = 0,inW = 0,inL = 0;
int outM = 0,outR = 0,outS = 0, outW = 0,outL = 0;
char *buffer1[20] = {};		// buffer between Mapper Pool Updater and Mapper threads
char *buffer2[20] = {};		// buffer between Mapper and Reducer threads
char *buffer3[20] = {};		// buffer between Reducer and Summarizer threads
char *buffer4[20] = {};		// buffer between Summarizer and Word Count Writer thread
char *buffer5[20] = {};		// buffer between Summarizers and Letter Count Writer thread
int endM=0,endR=0,endS=0,endW=0,endL=0;
int completedM = 0,completedR = 0,completedS = 0,completedW = 0,completedL = 0;
int a=0,b=0; 	// Modified by threads
int num_of_Mappers=0, num_of_Reducers=0, num_of_Summarizers=0; // Threads;
int n = 0;	    // Total words in file
int flag = 0,flag1 = 0;

char tmp0[50],tmp1[50],tmp2[50];
char tempM[5] = "@";	
char tempR[10] = "(@,0)";

int x = 0,p = 0,y = 0,q = 0;
char *nodeR[MAX],*nodeS[MAX];
int wCnt[MAX],lCnt[MAX];
int countR=0,countS=0;
int wordCount=0,letterCount;	


// Mutual Exclusion between Mapper Pool Updater and Mappers
pthread_mutex_t mutexM = PTHREAD_MUTEX_INITIALIZER;
pthread_cond_t  emptyM = PTHREAD_COND_INITIALIZER;
pthread_cond_t  fullM = PTHREAD_COND_INITIALIZER;


// Mutual Exclusion between Mappers and Reducers
pthread_mutex_t mutexR = PTHREAD_MUTEX_INITIALIZER;
pthread_cond_t  emptyR = PTHREAD_COND_INITIALIZER;
pthread_cond_t  fullR = PTHREAD_COND_INITIALIZER;


// Mutual Exclusion between Reducers and Summarizers
pthread_mutex_t mutexS = PTHREAD_MUTEX_INITIALIZER;
pthread_cond_t  emptyS = PTHREAD_COND_INITIALIZER;
pthread_cond_t  fullS = PTHREAD_COND_INITIALIZER;


// Mutual Exclusion between Summarizers and Word Count Writer
pthread_mutex_t mutexW = PTHREAD_MUTEX_INITIALIZER;
pthread_cond_t  emptyW = PTHREAD_COND_INITIALIZER;
pthread_cond_t  fullW = PTHREAD_COND_INITIALIZER;


// Mutual Exclusion between Summarizers and Letter Count Writer
pthread_mutex_t mutexL = PTHREAD_MUTEX_INITIALIZER;
pthread_cond_t  emptyL = PTHREAD_COND_INITIALIZER;
pthread_cond_t  fullL = PTHREAD_COND_INITIALIZER; 


// Produces an item and puts it into the buffer
void* mapperPool_updater(void *args) {

	char item[100];
	completedM = 0;
	endM = 0;

		for(int i=0;fscanf(fp,"%s",item)!=EOF;i++) {
				
				if(flag == 0) {
				p = item[0] - 97;
				q = item[0] - 97;
				flag = 1;
				}

				// Start critical section
				pthread_mutex_lock(&mutexM);

				while(numM == N) {
					pthread_cond_wait(&fullM, &mutexM);
				}

				buffer1[inM] = strdup(item);
				
				inM = (inM + 1) % N;  // circular buffer
				numM++;

				if(numM == 1)
      				pthread_cond_signal(&emptyM);

				// End critical section
				pthread_mutex_unlock(&mutexM);
		}
	buffer1[inM] = tempM;
	completedM = 1;	
	endM = numM+1;	
	pthread_cond_broadcast(&emptyM);
	pthread_exit(0);

}

// Removes an item from the buffer
void* Mappers_stage(void *args) {
		

		for(int i=0;(completedM == 0 || endM != 0);i++) { 

			
			// Start critical section
			pthread_mutex_lock(&mutexM);

				while( numM == 0 && !completedM) {
					pthread_cond_wait(&emptyM, &mutexM);
				}

				if(!completedM || endM != 0) {

						
				/////////////////////////////////////////////////////////

						// Start inner critical section
						pthread_mutex_lock(&mutexR);

						while(numR == N) {
							pthread_cond_wait(&fullR, &mutexR);
						}

						// creating (word,1) tuple						
						strcpy(tmp0,"(");
						strcat(tmp0,buffer1[outM]);
						strcat(tmp0,",");
						sprintf(tmp0,"%s%d",tmp0,1);
						strcat(tmp0,")");

						buffer2[inR] = strdup(tmp0);					
						inR = (inR + 1) % N;  // circular buffer
						numR++;
						if(numR == 1)
		      				pthread_cond_signal(&emptyR);

						// End inner critical section
						pthread_mutex_unlock(&mutexR);

				/////////////////////////////////////////////////////////

				outM = (outM + 1) % N;
				numM--;

						
				if (numM == N-1) {
					pthread_cond_broadcast(&fullM);
				}

				if(completedM == 1) {
					endM--;
				}
						
			}
			
				// End critical section
				pthread_mutex_unlock(&mutexM);
		}


	completedR = 1;
	endR = numR;
	pthread_cond_broadcast(&emptyR);
	pthread_exit(0);

}



// Reducer Threads
void* Reducers_stage(void *args) {


	char *temp1,*temp2,*temp3,*str;	
	
		for(int i=0;(completedR == 0 || endR != 0);i++) { 

			
			// Start critical section
			pthread_mutex_lock(&mutexR);

				while( numR == 0 && !completedR) {
					pthread_cond_wait(&emptyR, &mutexR);
				}

				if(!completedR || endR != 0) {


				/////////////////////////////////////////////////////////
						

						// receive data from buffer
						// extract the first word from it
						// subtract 97 from it AND MAKE IT AS INDEX
						temp1 = buffer2[outR];

						// Unpacking the tuples
						temp1 = strtok(temp1,"(,");
						x = temp1[0] - 97;
						nodeR[countR] = temp1;
						countR++;


						// Here an index change suggests there is letter change
						// So the reducer has to start counting the occurrences 
						// of each word in that pool
						/////////////////////////////////////////////////////
							// Reducer started here
							if (x != p) {
									for (int a=0;a<countR-1;a++) {
										temp2 = nodeR[a];
										for(int b=a+1;b<countR;b++) {
											temp3 = nodeR[b];
											if(strcmp(temp2,temp3) == 0) {
												wordCount++;
	        									for(int c=b;c<countR;c++)	 // removing the repeated word from the list
	        										nodeR[c] = nodeR[c+1];
	        									b--;
	        									countR--;
											}


											if(b == countR-1) {

												// Start inner critical section
												pthread_mutex_lock(&mutexS);
												pthread_mutex_lock(&mutexW);

												while(numS == N || numW == N) {
													pthread_cond_wait(&fullS, &mutexS);
													pthread_cond_wait(&fullW, &mutexW);
												}
															wordCount++;

															str = nodeR[a];															
															// creating (word,count) tuple																										
															strcpy(tmp1,"(");
															strcat(tmp1,str);
															strcat(tmp1,",");
															sprintf(tmp1,"%s%d",tmp1,wordCount);
															strcat(tmp1,")");
															buffer3[inS] = strdup(tmp1);
															buffer4[inW] = strdup(tmp1);

															// For Word Count Writer

												inS = (inS + 1) % N;  // circular buffer	
												inW = (inW + 1) % N;								
												numS++;
												numW++;
												wordCount = 0;

												if(numS == 1 || numW == 1) {
			      									pthread_cond_signal(&emptyW);
			      									pthread_cond_signal(&emptyS);
												}

												// End inner critical section
												pthread_mutex_unlock(&mutexW);	
												pthread_mutex_unlock(&mutexS);											
										    }

										} 
										if(a == countR-2) {
												wordCount = 0;
												countR = 0;							
												nodeR[countR] = temp1;
												countR++;
										}
										
										
									}
									
						    }						   

				p = x; // Assigning previous index
				/////////////////////////////////////////////////////////

				outR = (outR + 1) % N;
				numR--;

				if (numR == N-1) {
					pthread_cond_broadcast(&fullR);
				}

				if(completedR == 1) {
					endR--;
				}
						
			}
			
				// End critical section
				pthread_mutex_unlock(&mutexR);
		}
	buffer3[inS] = tempR;
	completedS = 1;
	endS = numS+1;
	completedW = 1;
	endW = numW;
	pthread_cond_broadcast(&emptyS);
	pthread_cond_broadcast(&emptyW);
	pthread_exit(0);

}



// Summarizer Threads
void* Summarizers_stage(void *args) {


	char *temp4,*temp5,*temp6;

		for(int i=0;(completedS == 0 || endS != 0);i++) { 

			
			// Start critical section
			pthread_mutex_lock(&mutexS);
				while( numS == 0 && !completedS) {
					pthread_cond_wait(&emptyS, &mutexS);
				}

				if(!completedS || endS != 0) {

				/////////////////////////////////////////////////////////
						// Unpacking the tuples to get word and word count 							
						temp4 = strtok(buffer3[outS],"(,)");						
						temp5 = strtok(NULL,"(,)");																		
						y = temp4[0] - 97;
						nodeS[countS] = strdup(temp4);
						wCnt[countS] = (int)atoi(temp5);						
						countS++;						

							// Summarizer started here
							if (y != q) {
									for (int d=0;d<countS-1;d++) {										
										letterCount += wCnt[d];										
										}

										temp6 = nodeS[0];

										/////////////////////////////////////////////////////
												// Start inner critical section
												pthread_mutex_lock(&mutexL);

												while(numL == N) {													
													pthread_cond_wait(&fullL, &mutexL);
												}																				
															// creating (letter,totalCount) tuple					
															strcpy(tmp2,"(");
															sprintf(tmp2,"%s%c",tmp2,temp6[0]);
															strcat(tmp2,",");
															sprintf(tmp2,"%s%d",tmp2,letterCount);
															strcat(tmp2,")");															
															buffer5[inL] = strdup(tmp2);

															// For Word Count Writer

												inL = (inL + 1) % N;  // circular buffer									
												numL++;

												if(numL == 1) {
			      									pthread_cond_signal(&emptyL);
												}

												// End inner critical section
												pthread_mutex_unlock(&mutexL);	
										/////////////////////////////////////////////////////											
												letterCount = 0;
												countS = 0;	
												nodeS[countS] = strdup(temp4);
												wCnt[countS] = (int)atoi(temp5);
												countS++;

						    }

				q = y; // Assigning previous index
				/////////////////////////////////////////////////////////

				outS = (outS + 1) % N;
				numS--;
						
				if (numS == N-1) {
					pthread_cond_broadcast(&fullS);
				}

				if(completedS == 1) {
					endS--;
				}
						
			}
			
				// End critical section
				pthread_mutex_unlock(&mutexS);
		}

	completedL = 1;
	endL = numL;
	pthread_cond_broadcast(&emptyL);	
	pthread_exit(0);


}



// Reads from the Summarizer Pool and writes it	to file	wordCount.txt	

void* wordCount_writer(void *args) { 


	for(int i=0;(completedW == 0 || endW != 0);i++) { 

			// Start critical section
			pthread_mutex_lock(&mutexW);
				while( numW == 0 && !completedW) {
					pthread_cond_wait(&emptyW, &mutexW);
				}

				if(!completedW || endW != 0) {

					fprintf(fr,"%s\n",buffer4[outW]);

				outW = (outW + 1) % N;
				numW--;

						
				if (numW == N-1) {
					pthread_cond_broadcast(&fullW);
				}

				if(completedW == 1) {
					endW--;
				}
						
			}
			
			// End critical section
			pthread_mutex_unlock(&mutexW);
		}


pthread_exit(0);

}


// 
void* LetterCount_writer(void *args) { 

	for(int i=0;(completedL == 0 || endL != 0);i++) { 

			// Start critical section
			pthread_mutex_lock(&mutexL);

				while( numL == 0 && !completedL) {
					pthread_cond_wait(&emptyL, &mutexL);
				}

				if(!completedL || endL != 0) {

					fprintf(fs,"%s\n",buffer5[outL]);

				outL = (outL + 1) % N;
				numL--;

						
				if (numL == N-1) {
					pthread_cond_broadcast(&fullL);
				}

				if(completedL == 1) {
					endL--;
				}
						
			}
			
			// End critical section
			pthread_mutex_unlock(&mutexL);
		}


pthread_exit(0);

}



int main(int argc, char *argv[]) {


	// Checking for input arguments
    if(argc != 5) {
        if(argc < 5)
        printf("Insufficient arguments passed\n");
        else
        printf("Too many arguments passed\n");
        printf("usage: ./wordStatistics <input.txt> <# of Mapper threads> <# of Reducer threads> <# of Summarizer threads>\n");
        return 1;
    }

	// Opening the input file containing Words
    fp = fopen(argv[1], "r");

        if(fp == NULL) {
            printf("Cannot open the file.\n");
            printf("Input a valid text file..\n");
            exit(1);
        }

	if((fr = fopen("wordCount.txt", "w"))==NULL) {

            printf("Cannot open file.\n");
            exit(1);

    }

    if((fs = fopen("letterCount.txt", "w"))==NULL) {

            printf("Cannot open file.\n");
            exit(1);

    }

	// Mapper Pool Updater Thread
	pthread_t tidMPU;		
	pthread_create(&tidMPU, NULL, mapperPool_updater, NULL);
	
	
	// Mapper Threads
	num_of_Mappers = atoi(argv[2]);
	//mapThreads = num_of_Mappers;
	pthread_t mapperTIDs[num_of_Mappers];
	for(int i=0;i<num_of_Mappers;i++) { 
		pthread_create(&mapperTIDs[i], NULL, Mappers_stage, NULL);
	} 


	// Reducer Threads
	num_of_Reducers = atoi(argv[3]);

	pthread_t reducerTIDs[num_of_Reducers];
	for(int i=0;i<num_of_Reducers;i++) { 
		pthread_create(&reducerTIDs[i], NULL, Reducers_stage, NULL);
	}


	// Summarizer Threads
	num_of_Summarizers = atoi(argv[4]);

	pthread_t summarizerTIDs[num_of_Summarizers];
	for(int i=0;i<num_of_Summarizers;i++) { 
		pthread_create(&summarizerTIDs[i], NULL, Summarizers_stage, NULL);
	}

	// Word	Count Thread
	pthread_t tidWCnt;		
	pthread_create(&tidWCnt, NULL, wordCount_writer, NULL);


	// Letter Count Writer Thread
	pthread_t tidLCnt;		
	pthread_create(&tidLCnt, NULL, LetterCount_writer, NULL);


	// wait for Mapper Pool Updater Thread to finish
	pthread_join(tidMPU, NULL);


	// wait for Mapper Threads to finish
	for(int i=0;i<num_of_Mappers;i++) { 
		pthread_join(mapperTIDs[i], NULL);
		//printf("Mapper Thead %p exited\n", (void *)mapperTIDs[i]);
	}

	// wait for Reducer Threads to finish
	for(int i=0;i<num_of_Reducers;i++) { 
		pthread_join(reducerTIDs[i], NULL);
		//printf("Mapper Thead %p exited\n", (void *)mapperTIDs[i]);
	}

	// wait for Summarizer Threads to finish
	for(int i=0;i<num_of_Summarizers;i++) { 
		pthread_join(summarizerTIDs[i], NULL);
		//printf("Mapper Thead %p exited\n", (void *)mapperTIDs[i]);
	}

	// wait for Word Count Writer Thread to finish
	pthread_join(tidWCnt, NULL);

	// wait for Letter Count Writer Thread to finish
	pthread_join(tidLCnt, NULL);

	printf("----- Main thread exited---------------\n");
	printf("----- Following files are created -----\n");
	printf("wordCount.txt which contains (word,count) tuples\n");
	printf("letterCount.txt which contains (letter,count) tuples\n");
	fclose(fp);
	fclose(fr);
	fclose(fs);
	return 0;
}