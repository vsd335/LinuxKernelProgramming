Name : Vinayak Deshpande 
UFID : 4102 9538
Date : 02/8/2016

I. Files Included
-----------------
wordStatistics.c	- Implements Producer-Consumer design to map and reduce words from an input text file
Makefile			- Consists of all necessary commands to run the "wordStatistics" program in one step
Inputfile.txt		- This file has a list of words and it is input to the "wordStatistics" program


II. How to run the wordStatistics
---------------------------

Command Line Arguments and outputs

Step1 : make
Step2 : ./wordStatistics <input text file here> <number of mapper threads> <number of reducer threads> <number of summarizer threads>

Outputs:
"wordCount.txt" file which contains (word,count) tuples
"letterCount.txt" file which contains (letter,count) tuples


III. Design decisions
---------------------
There are total 5 producer-consumer relationships in this code

Implementation of Mapper Pool Updater PROGRAM
- There is always one Mapper Pool Updater thread which reads words from an input file
- These words are sent through a bounded buffer to mapper threads


Implementation of Mapper(s) PROGRAM
- There can be 1:n mapper threads which consume words produced by the mapper pool updater
- Mapper threads produce mapped outputs of the format (word,1) 


Implementation of Reducer(s) PROGRAM
- There can be 1:n reducer threads which consume words produced by the mapper threads
- Reducer threads produce reduced outputs of the format (word,count)


Implementation of Summarizer(s) PROGRAM
- There can be 1:n summarizer threads which consume words produced by the reducer threads
- Summarizer threads produce summarized outputs of the format (letter,totalCount)


Implementation of Word Count Writer and Letter Count Writer PROGRAMS
- Word Count Writer is a single thread which consumes words produced by Reducer and writes to an output file called "wordCount.txt"
- Letter Count Writer is a single thread which consumes words produced by Summarizer and writes to an output file called "letterCount.txt"


