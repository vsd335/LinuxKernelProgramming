Name: Vinayak Deshpande
UFID: 4102 9538


Files included: 
Userapp programs:
assignment5.c  // Added few print statements
deadlock1.c
deadlock2.c
deadlock3.c
deadlock4.c
deadlock5.c
Makefile.c


Instructions to Run the above userapp files (all the files are included in single Makefile)

$ make 
$ sudo insmod assignment5.ko
$ make <deadlock1 or deadlock2 or deadlock3 or deadlock4 or deadlock5>
$ sudo <./deadlock1 or ./deadlock2 or ./deadlock3 or ./deadlock4 or ./deadlock5>

output: Lead to deadlock

Notes: For deadlock1, deadlock2, deadlock4 and deadlock5, it requires us to restart the system, as its kernel deadlock.
       For deadlock3 and deadlock5, ctrl+c will solve the deadlock

There are total four userapp testcases written.
There are two real deadlocks i.e the first two scenarios lead to real deadlocks.
The third scenario is where the device does not go into real deadlock.
For all these deadlocks, I have not made any changes to the driver code, except for adding few printk statements
in all entry functions.

DEADLOCKS
----------

1) deadlock1 : One thread get stuck in ioctl and other in open waiting for sem2
	- This is a real deadlock(kernel)
	- Set the mode to MODE1
	- Let the two threads(1 and 2) open the devide in MODE1 at the same time
	- So Count1=2
	- thread2 will wait in open as Sem2 is acquired by thread1
	- Now let thread1(one which has acquired sem2) change mode to MODE2 in ioctl
	- Since count1>1, the thread1 will get stuck in queue1(line Number 156 in provided driver code)
	- So both thread1 and thread2 get into a deadlock 

2) deadlock2 : Both threads get stuck in ioctl
	- This is a real deadlock(kernel)
	- Set the mode to MODE1
	- Let a thread1 open the device, so count1=1, count2=0
	- Now thread1 changes the mode to MODE2, count1=0, count2=1
	- Let this thread1 release the device, so count1=0, count2=0
	- Now let two threads open the device in MoDE2, count2=2
	- Now both threads try to change mode to MODE1
	- Since count2>1, both threads get stuck in queue2(line Number 174 in provided driver code)

3) deadlock3 : 
	- The device starts for the first time in MODE1
	- A threads in user program tries to open the device twice
	- This leads to a deadlock as the device is closed only once where as it is opened twice
	- The two instances opened by the same thread get stuck in queue2 of wait statement(line Number 174 in provided driver code)
	
	
4) deadlock4 :
	- This is a real deadlock(kernel)
	- In this scenario, we make use of locks in the userapp to replicate the deadlock scenario
	- we spawn three new threads that will require a mutex lock to open the device and perform ioctl
	- One thread acquires a lock and opens the device and changes mode to MODE2 and comes back to userapp and releases lock
	  and goes to sleep.
	- Now another thread acquires lock and opens device and tries to perform ioctl, but the count2 is still 2, so it
	  goes into queue2
	- Now the first thread wakes up from sleep and performs ioctl and gets stuck since count2>1
	- Here the major point is that, the second thread has still acquired the lock.
	- So any other thread in user space can open the device as they require mutex lock.
	- This is another real deadlock, where adding more threads or processes will not solve the deadlock problem
	
	
5) deadlock5 :  
	- A thread opens in MODE1 and then changes the mode to MODE2
	- Now two new threads get spawned and they start at the same time as barrier is used for synchronization
	- These two devices get into a deadlock in MODE2


RACE CONDITIONS
---------------

These are the possbile race conditions, where more than one thread/process make changes to the vulenrable device data.

1) Two processes trying to read at the same time in MODE1
	we have the following code for MODE2 in read function
	Lock held at the time: sem1
	
		down_interruptible(&devc->sem1);   
	if (devc->mode == MODE1) {
	   up(&devc->sem1);
           if (*f_pos + count > ramdisk_size) {
              printk("Trying to read past end of buffer!\n");
              return ret;
           }
	   ret = count - copy_to_user(buf, devc->ramdisk, count);
	}
	else {
          if (*f_pos + count > ramdisk_size) {
             printk("Trying to read past end of buffer!\n");
             up(&devc->sem1);
             return ret;
          }
          ret = count - copy_to_user(buf, devc->ramdisk, count);
	  up(&devc->sem1);
	}
	
	- This scenario can be created as follows:
	  1) Open a file descriptor in parent process
	  2) create two new processes which will share the same file descriptor
	  3) When these two processes open the device they overwrite the count1 value(count1 remains 1)
	  4) Now these two processes can read from the ramdisk at the same time
	
2)  Two processes trying to write at the same time in MODE1
	we have the following code for MODE2 in write function (line number 118)
	Lock held at the time: sem1
	
		down_interruptible(&devc->sem1);
	if (devc->mode == MODE1) {
		up(&devc->sem1);
        if (*f_pos + count > ramdisk_size) {
            printk("Trying to read past end of buffer!\n");
            return ret;
        }
        ret = count - copy_from_user(devc->ramdisk, buf, count);
	}
	else {
        if (*f_pos + count > ramdisk_size) {
            printk("Trying to read past end of buffer!\n");
            up(&devc->sem1);
            return ret;
        }
        ret = count - copy_from_user(devc->ramdisk, buf, count);
		up(&devc->sem1);
	}

	- This scenario can be created as follows:
	  1) Open a file descriptor in parent process
	  2) create two new processes which will share the same file descriptor
	  3) When these two processes open the device they overwrite the count1 value(count1 remains 1)
	  4) Now these two processes can write to the ramdisk at the same time
	
	
3)  In open entry function: Count1 or Count2 is always overwritten when multiple processes with same file descriptor 
    open the device
	Lock held at the time: sem1
	For example:
	
			down_interruptible(&devc->sem1);
			if (devc->mode == MODE1) {
				devc->count1++;
				up(&devc->sem1);
				down_interruptible(&devc->sem2);
				return 0;
			}
			else if (devc->mode == MODE2) {
				devc->count2++;
			}
			up(&devc->sem1);

	- Here say in MODE2 each process enters and increments count2 by 1, but count2 will always remain 1 as each process
	  will have its own copy of count2.
	  
	- Similarly in MODE1, count1 always reflects 1 and not the number of processes that have opened the device.
	- These two scenarios are potential race conditions
	
4) A first arrived thread reads data modified by another writing thread
	- In MODE2 we can have multiple processes/threads read and write concurrently
	- Now a thread2 wants to read data already written by thread1
	- But it may so happen that, the thread1 is interrupted by an external event like timer before it acquires sem1
	- Now another thread3 arrives to write data to ramdisk and it writes and unlcoks the sem1
	- The interrupted thread2 now acquires sem1 and tries to read data written by thread1 but ends up reading data written by 
	  thread3, this leads to data race and hence corrupting the data
	  
	   
5) The device is not protected in mode2 whereas  in mode1 it is protected. In mode1, the multiple instances of opening 
the device is protected by sem2 whereas in mode2 the device is not locked, so multiple instances of device can be opened 
concurrently which might lead to race conditions. One such critical region code is shown below
down_interruptible(&devc->sem1);
	if (devc->mode == MODE1) {
			…. ….. ……..
	}
	else {
	if (*f_pos + count > ramdisk_size) {
				printk("Trying to read past end of buffer!\n");
				up(&devc->sem1);
				return ret;
	   }
	   ret = count - copy_from_user(devc->ramdisk, buf, count);
	up(&devc->sem1);
	}
	
	- Here multiple processes/threads can write to the device, so the data integrity depends on the process which writes last.
	
6) Whenever a read/write is succesful, the file offset position should be updated, but its not the case in both MODE1 and MODE2.
This leads to a race condition, where the f_pos position is set to the beginning the ramdisk. 
	
	*ppos += nbytes; //This line should be added in the read and write functions to avoid the race conditions.

7)  Two or more processes trying to read at the same time in MODE2
	we have the following code for MODE2 in read function
	
	down_interruptible(&devc->sem1);   
	if (devc->mode == MODE1) {
	   up(&devc->sem1);
           if (*f_pos + count > ramdisk_size) {
              printk("Trying to read past end of buffer!\n");
              return ret;
           }
	   ret = count - copy_to_user(buf, devc->ramdisk, count);
	}
	else {
          if (*f_pos + count > ramdisk_size) {
             printk("Trying to read past end of buffer!\n");
             up(&devc->sem1);
             return ret;
          }
          ret = count - copy_to_user(buf, devc->ramdisk, count);
	  up(&devc->sem1);
	}
	
	- Here we can see that, the read to the device is protected by making use of semaphore sem1
	- If there is no semaphore used for synchronization, we can have multiple instances of the device read or write concurrently
	  in MODE2 hence leading to data race condition.
	  
8)  Two or more processes trying to write at the same time in MODE2
	we have the following code for MODE2 in write function
	
	down_interruptible(&devc->sem1);
	if (devc->mode == MODE1) {
		up(&devc->sem1);
        if (*f_pos + count > ramdisk_size) {
            printk("Trying to read past end of buffer!\n");
            return ret;
        }
        ret = count - copy_from_user(devc->ramdisk, buf, count);
	}
	else {
        if (*f_pos + count > ramdisk_size) {
            printk("Trying to read past end of buffer!\n");
            up(&devc->sem1);
            return ret;
        }
        ret = count - copy_from_user(devc->ramdisk, buf, count);
		up(&devc->sem1);
	}
	
	- Here we can see that, the write to the device is protected by making use of semaphore sem1
	- If there is no semaphore used for synchronization, we can have multiple instances of the device write concurrently
	  in MODE2 hence leading to data race condition.
