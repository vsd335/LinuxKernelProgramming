#include "semap.h"

semaphore_t *semaphore_create(char *semaphore_name,int num) {
	
    int fd;
    semaphore_t *semap;
    pthread_mutexattr_t psharedm;
    pthread_condattr_t psharedc;

    fd = shm_open(semaphore_name, O_RDWR | O_CREAT , 0666);
    
    if (fd < 0)
    {
        perror("shm_open");
        return (NULL);
    }
    (void) ftruncate(fd, sizeof(semaphore_t)+num*(sizeof(philSem)));
    (void) pthread_mutexattr_init(&psharedm);
    (void) pthread_mutexattr_setpshared(&psharedm,PTHREAD_PROCESS_SHARED);
    (void) pthread_condattr_init(&psharedc);
    (void) pthread_condattr_setpshared(&psharedc,PTHREAD_PROCESS_SHARED);
    semap = (semaphore_t *) mmap(NULL, sizeof(semaphore_t)+num*(sizeof(philSem)), PROT_READ | PROT_WRITE, MAP_SHARED , fd, 0);
    close (fd);
    (void) pthread_mutex_init(&semap->barrier, &psharedm);
    (void) pthread_cond_init(&semap->barrVal, &psharedc);
    semap->barr_count = 0;

    for(int k=0;k<num;k++)
    {
		(void) sem_init(&semap->philS[k].philLock,1,0);
        semap->philS[k].state=THINKING;
    }
    (void)sem_init(&semap->mutex,1,1);
  	
    return (semap);
	
}

semaphore_t *semaphore_open(char *semaphore_name,int num) {
	
    int fd;
    semaphore_t *semap;
    fd = shm_open(semaphore_name, O_RDWR, 0666);
    if (fd < 0)
        return (NULL);
    semap = (semaphore_t *) mmap(NULL, sizeof(semaphore_t)+num*sizeof(philSem), PROT_READ | PROT_WRITE, MAP_SHARED, fd, 0);
    close (fd);
    return (semap);
	
}
/*
void semaphore_post(semaphore_t *semap)
{
    pthread_mutex_lock(&semap->lock);
    if (semap->count == 0)
        pthread_cond_signal(&semap->nonzero);
    semap->count++;
    pthread_mutex_unlock(&semap->lock);
}


void semaphore_wait(semaphore_t *semap)
{
    pthread_mutex_lock(&semap->lock);
    while (semap->count == 0)
        pthread_cond_wait(&semap->nonzero, &semap->lock);
    semap->count--;
    pthread_mutex_unlock(&semap->lock);
}
*/
void semaphore_close(semaphore_t *semap,int num) {
	
    munmap((void *) semap, sizeof(semaphore_t)+num*sizeof(philSem));
	
}