
Name : Vinayak Deshpande 
UFID : 4102 9538
Date : 02/22/2016

I. Files Included
-----------------
Host.c			- Initializes data structure for N philosophers using mmap
Philosopher.c		- The program checks for various states of each philosopher
semap.h			- Defines required semaphore structure, mutex and conditional variables
semap.h			- Includes mmap create and open functions
Makefile		- Consists of all necessary commands to run the "Host" program in one step


II. How to run the Host Program
-------------------------------

Command Line Arguments and outputs

Step1 : make
Step2 : ./Host <# of philosophers> <# of iterations>

Outputs:
Each philosopher prints its state {THINKING, HUNGRY, and EATING} on the terminal


III. Design decisions
---------------------

Implementation of Host PROGRAM
- Accepts arguments : N(Number of philosophers) and M(Number of iterations)
- Initializes data structure for N philosophers using mmap
- Spawns new processes using fork() and changes the program image of each process to that of Philosopher using exec()
- The Host program finally waits for all the children process to terminate before it exit.


Implementation of Philosopher PROGRAM
- All the philosopher processes run this program
- The program checks for various states of each philosopher
- Each philosophers will be in either of {THINKING, HUNGRY, and EATING} states
- A philosopher can not EAT if the neighboring philosophers are already EATING
- A barrier synchronization is used to ensure all the philosophers arrive at the same time

