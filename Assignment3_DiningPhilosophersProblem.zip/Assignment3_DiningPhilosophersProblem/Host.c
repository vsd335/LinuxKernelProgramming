/* 
	NAME : Vinayak Deshpande
	UFID : 4102 9538

*/

/* 
   Host: Initializes the shared	data structures	based on the number	of philosophers(N),	which is provided as 
   a command line argument. After the initialization stage it creates N processes that execute the Philosopher	
   program. It will pass the 2nd command line argument (M or the number of iterations) to these processes 
   through exec system call.
*/


//Header files
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>		
#include <sys/types.h> 
#include <sys/wait.h>
#include <sys/stat.h>
#include <sys/mman.h>	
#include <fcntl.h>
#include <pthread.h>
#include "semap.c"

int N;

int main(int argc, char *argv[])
{
	
	// Checking for input arguments
    if(argc != 3) {
        if(argc < 3)
        	printf("Insufficient arguments passed\n");
        else
        	printf("Too many arguments passed\n");
        	printf("usage: ./Host <# of philosophers> <# of iterations>\n");
        return 1;
    }

	N = atoi(argv[1]);		// Number of philosophers

	pid_t* pids=(pid_t*)malloc(sizeof(pid_t)*N);
	
	semaphore_t *semap;	
	semap = semaphore_create("semaphore",N);	// Data structure initialization for N philosophers
	if (semap == NULL)
        	exit(1);
	
	// Creating N philosopher processes
	for (int i=0;i<N;i++) {
		
		char arg[2];
		sprintf(arg,"%d",i);			// associating each process with a unique number
		
		pids[i] = fork();				// Creating N child processes
		
		if(pids[i] == 0) {
			
			// Inside the child process
			execlp("./Philosopher", "./Philosopher", argv[1], argv[2], arg, NULL);
			printf("Exec error\n");		// executed by the child process only if execlp fails

		}
		
		else if(pids[i] < 0) {
			
			perror("fork error");				// fork failed
		}
		
	}
	
	// Parent will wait for the children to finish
	int status;
	
	while(N > 0) {
		
		wait(&status);
		N--;
	}
	
	printf("\n");
	printf("All the philosophers have exited..!!\n");
	printf("The parent has exited..!!\n");
	free(pids);
	semaphore_close(semap,N);	
	return 0;
}



